package personagens;
import armas.*;

public abstract class Personagem {
	
	String nome;
	int HP, AC;
	boolean exausto;
	Arma_IF arma;

	
	public Personagem(int HP, int AC) {
		this.HP = HP;
		this.AC = AC;
		exausto = false;
	}
	
	public abstract void desenhar(String c, String t);
		
	public int arma(int AC) {
		return arma.usarArma(AC);
	}
	
	public void setArma(Arma_IF arma) {
		this.arma = arma;
	}
	
	public int consultarHP() {
		return this.HP;
	}
	
	public int consultarAC() {
		return this.AC;
	}
	
	public Arma_IF consultarArma() {
		return this.arma;
	}

	public String consultarNome() {
		return this.nome;
	}
	
}
