package personagens;
import javax.swing.ImageIcon;

import armas.*;

public abstract class Personagem {
	
	public String nome;
	public int HP, AC;
	public boolean exausto;
	public Arma_IF arma;
	public ImageIcon icone;
	public int abates;
	public int persuasoes;
	public int fugas;

	
	public Personagem() {
		exausto = false;
		abates = 0;
		persuasoes = 0;
		fugas = 0;
	}
	
	public abstract void desenhar(String c, String t);
		
	public int arma(int AC) {
		return arma.usarArma(AC);
	}
	
	public void setArma(Arma_IF arma) {
		this.arma = arma;
	}
	
}
