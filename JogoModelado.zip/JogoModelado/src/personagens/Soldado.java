package personagens;

import armas.Revolver;
import mainPackage.InOut;
import armas.Faca;

public class Soldado extends Racional implements Terrestre {
	
	public Soldado() {
		super(50, 16);
		super.arma = new Revolver();
		super.nome = "Soldado";
	}
			
	@Override
	public void desenhar() {

	}
	
	@Override
	public int arma(int AC) {
		int dano = arma.usarArma(AC);
		if(dano == -1) {
			super.arma = new Faca();
			return 0;
		} else {
			return dano;
		}
	}
	
	public boolean correr() {
		if(super.exausto) {
			System.out.println("Você não consegue correr pois está exausto!");
			return false;
		} else {
			System.out.println("Você corre!");
			super.exausto = true;
			return true;
		}
	}
	

}
