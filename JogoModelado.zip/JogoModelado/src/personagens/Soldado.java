package personagens;

import armas.Revolver;
import mainPackage.InOut;

import javax.swing.ImageIcon;

import armas.Faca;

public class Soldado extends Racional implements Terrestre {
	
	public Soldado() {
		super.HP = 50;
		super.AC = 15;
		super.arma = new Revolver();
		super.nome = "Soldado";
		super.icone = new ImageIcon("soldado.png");
	}
			
	@Override
	public void desenhar(String c, String t) {
		InOut.MsgDeInformacao(c, t, super.icone);
	}
	
	@Override
	public int arma(int AC) {
		int dano = arma.usarArma(AC);
		if(dano == -1) {
			super.arma = new Faca();
			return arma.usarArma(AC);
		} else {
			return dano;
		}
	}
	
	public boolean correr() {
		if(super.exausto) {
			System.out.println("Você não consegue correr pois está exausto!");
			return false;
		} else {
			System.out.println("Você corre!");
			super.exausto = true;
			return true;
		}
	}
	

}
