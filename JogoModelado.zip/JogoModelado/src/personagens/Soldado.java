package personagens;

import armas.Revolver;
import mainPackage.InOut;
import armas.Faca;

public class Soldado extends Militar implements Terrestre {
	
	public Soldado() {
		super(50, 16);
		int armaSwitch;
		while(true) {
			armaSwitch = InOut.leInt("Escolhe a arma do General\n"
					+ " -0: Faca\n"
					+ " -1: Revolver\n");
			if(armaSwitch > 1 || armaSwitch < 0)
				InOut.MsgDeErro("ERRO DE ENTRADA", "Digite 0 ou 1");
			else 
				break;
		}
		switch(armaSwitch) {
		case 0: super.arma = new Faca();
		break;
		case 1: super.arma = new Revolver();
		break;
		}
	}
			
	@Override
	public void desenhar() {

	}
	
	public boolean correr() {
		if(super.exausto) {
			System.out.println("Você não consegue correr pois está exausto!");
			return false;
		} else {
			System.out.println("Você corre!");
			super.exausto = true;
			return true;
		}
	}
	

}
