package personagens;

public abstract class Militar extends Racional {
	
	int municao;

	public Militar(int HP, int AC) {
		super(HP, AC);
	}

	@Override
	public void desenhar() {
		
		
	}


}
