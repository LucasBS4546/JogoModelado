package personagens;

import armas.Magia;

public class Mago extends Racional implements Terrestre, Voador {
	
	boolean semMana;
	
	public Mago() {
		super(35, 15);
		super.setArma(new Magia());
		semMana = false;
		super.nome = "Mago";
	}
	
	@Override
	public void desenhar() {
		
	}
	
	public boolean correr() {
		if(super.exausto) {
			System.out.println("Você não consegue correr pois está exausto!");
			return false;
		} else {
			System.out.println("Você corre!");
			super.exausto = true;
			return true;
		}
	}
	
	public boolean voar() {
		if(semMana) {
			System.out.println("Você não consegue voar pois está sem mana!");
			return false;
		} else {
			System.out.println("Você voa!");
			semMana = true;
			return true;
		}
	}
	
}