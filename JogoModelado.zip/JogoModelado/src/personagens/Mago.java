package personagens;

import javax.swing.ImageIcon;

import armas.Magia;
import mainPackage.InOut;

public class Mago extends Racional implements Terrestre {
	
	public Mago() {
		super.HP = 50;
		super.AC = 13;
		super.setArma(new Magia());
		super.nome = "Mago";
		super.icone = new ImageIcon("mago.png");
	}
	
	@Override
	public void desenhar(String c, String t) {
		InOut.MsgDeInformacao(c, t, super.icone);
	}
	
	public boolean correr() {
		if(super.exausto) {
			System.out.println("Você não consegue correr pois está exausto!");
			return false;
		} else {
			System.out.println("Você corre!");
			super.exausto = true;
			return true;
		}
	}
	
}