package personagens;

import armas.Magia;
import mainPackage.InOut;

public class Mago extends Racional implements Terrestre {

	
	public Mago() {
		super(35, 15);
		super.setArma(new Magia());
		super.nome = "Mago";
	}
	
	@Override
	public void desenhar(String c, String t) {
		InOut.MsgDeInformacao(c, t, 0);
	}
	
	public boolean correr() {
		if(super.exausto) {
			System.out.println("Você não consegue correr pois está exausto!");
			return false;
		} else {
			System.out.println("Você corre!");
			super.exausto = true;
			return true;
		}
	}
	
}