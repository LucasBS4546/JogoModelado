package personagens;

import armas.SoproCongelante;
import mainPackage.InOut;

public class DragaoAlado extends Irracional implements Voador {
	
	
	public DragaoAlado() {
		super(200, 20);
		super.setArma(new SoproCongelante());
		super.nome = "DragaoAlado";
	}
	
	@Override
	public void desenhar(String c, String t) {
		InOut.MsgDeInformacao(c, t, 4);
	}
		
	public boolean voar() {
		if(super.exausto) {
			System.out.println("Você não consegue voar pois está exausto!");
			return false;
		} else {
			System.out.println("Você voa!");
			super.exausto = true;
			return true;
		}
	}

}
