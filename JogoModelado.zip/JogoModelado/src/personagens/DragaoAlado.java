package personagens;

import javax.swing.ImageIcon;

import armas.SoproCongelante;
import mainPackage.InOut;

public class DragaoAlado extends Personagem implements Voador {
	
	
	public DragaoAlado() {
		super.HP = 100;
		super.AC = 15;
		super.setArma(new SoproCongelante());
		super.nome = "Dragao Alado";
		super.icone = new ImageIcon("dragao.png");
	}
	
	@Override
	public void desenhar(String c, String t) {
		InOut.MsgDeInformacao(c, t, super.icone);
	}
		
	public boolean voar() {
		if(super.exausto) {
			System.out.println("Você não consegue voar pois está exausto!");
			return false;
		} else {
			System.out.println("Você voa!");
			super.exausto = true;
			return true;
		}
	}

}
