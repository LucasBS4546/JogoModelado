package personagens;

import armas.SoproCongelante;

public class DragaoAlado extends Irracional implements Voador {
	
	
	public DragaoAlado() {
		super(200, 20);
		super.setArma(new SoproCongelante());
	}
	
	@Override
	public void desenhar() {
		
	}
		
	public boolean voar() {
		if(super.exausto) {
			System.out.println("Você não consegue voar pois está exausto!");
			return false;
		} else {
			System.out.println("Você voa!");
			super.exausto = true;
			return true;
		}
	}

}
