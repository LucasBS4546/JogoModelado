package personagens;

import mainPackage.InOut;

public abstract class Racional extends Personagem {

	
	public static String falar() {
		String fala = InOut.leString("Digite o que voce vai falar.");
		return fala;
	}

}
