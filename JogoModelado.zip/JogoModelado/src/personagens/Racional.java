package personagens;

import mainPackage.InOut;

public abstract class Racional extends Personagem {

	public Racional(int HP, int AC) {
		super(HP, AC);
	}
	
	public String falar() {
		String fala = InOut.leString("Digite o que voce vai falar.");
		return fala;
	}

}
