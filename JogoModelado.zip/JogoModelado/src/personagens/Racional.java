package personagens;

public abstract class Racional extends Personagem {

	public Racional(int HP, int AC) {
		super(HP, AC);
	}
	
	public void falar(String texto) {
		System.out.println("\"" + texto + "\"");
	}

}
