package personagens;

import armas.Fuzil;
import armas.Revolver;

import armas.Faca;
import mainPackage.InOut;

public class General extends Militar implements Terrestre {

	public General() {
		super(60, 17);
		int armaSwitch;
		while(true) {
			armaSwitch = InOut.leInt("Escolhe a arma do General\n"
					+ " -0: Faca\n"
					+ " -1: Revolver\n"
					+ " -2: Fuzil");
			if(armaSwitch > 2 || armaSwitch < 0)
				InOut.MsgDeErro("ERRO DE ENTRADA", "Digite 0, 1 ou 2");
			else 
				break;
		}
		switch(armaSwitch) {
		case 0: super.arma = new Faca();
		break;
		case 1: super.arma = new Revolver();
		break;
		case 2: super.arma = new Fuzil();
		break;
		}
	}
	
	@Override
	public void desenhar() {
		
	}
	
	public boolean correr() {
		if(super.exausto) {
			System.out.println("Você não consegue correr pois está exausto!");
			return false;
		} else {
			System.out.println("Você corre!");
			super.exausto = true;
			return true;
		}
	}
	
}
