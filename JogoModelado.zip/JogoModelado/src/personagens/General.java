package personagens;

import armas.Fuzil;
import armas.Revolver;

import armas.Faca;
import mainPackage.InOut;

public class General extends Racional implements Terrestre {

	public General() {
		super(60, 17);
		super.arma = new Fuzil();
		super.nome = "General";
	}
	
	@Override
	public void desenhar(String c, String t) {
		InOut.MsgDeInformacao(c, t, 2);
	}
	
	@Override
	public int arma(int AC) {
		int dano = arma.usarArma(AC);
		if(dano == -1) {
			super.arma = new Faca();
			return 0;
		} else {
			return dano;
		}
	}
	
	public boolean correr() {
		if(super.exausto) {
			System.out.println("Você não consegue correr pois está exausto!");
			return false;
		} else {
			System.out.println("Você corre!");
			super.exausto = true;
			return true;
		}
	}
	
}
