package personagens;

public interface Terrestre {
	
	public boolean correr();

}
