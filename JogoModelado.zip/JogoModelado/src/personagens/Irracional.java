package personagens;

public abstract class Irracional extends Personagem {

	public Irracional(int HP, int AC) {
		super(HP, AC);
	}

}
