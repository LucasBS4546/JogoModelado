package personagens;

public interface Voador {

	public boolean voar();

}
