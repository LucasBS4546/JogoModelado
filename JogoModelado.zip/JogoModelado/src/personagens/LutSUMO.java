package personagens;

import armas.Desarmado;
import mainPackage.InOut;

public class LutSUMO extends Racional implements Terrestre{
	
	public LutSUMO() {
		super(120, 13);
		super.setArma(new Desarmado());
		super.nome = "LutSUMO";
	}
	
	@Override
	public void desenhar(String c, String t) {
		InOut.MsgDeInformacao(c, t, 3);
	}
	
	public boolean correr() {
		if(super.exausto) {
			System.out.println("Você não consegue correr pois está exausto!");
			return false;
		} else {
			System.out.println("Você corre!");
			super.exausto = true;
			return true;
		}
	}
	
}
