package personagens;

import javax.swing.ImageIcon;

import armas.Desarmado;
import mainPackage.InOut;

public class LutSUMO extends Racional implements Terrestre{
	
	public LutSUMO() {
		super.HP = 50;
		super.AC = 15;
		super.setArma(new Desarmado());
		super.nome = "Lutador de sumo";
		super.icone = new ImageIcon("sumo.png");
	}
	
	@Override
	public void desenhar(String c, String t) {
		InOut.MsgDeInformacao(c, t, super.icone);
	}
	
	public boolean correr() {
		if(super.exausto) {
			System.out.println("Você não consegue correr pois está exausto!");
			return false;
		} else {
			System.out.println("Você corre!");
			super.exausto = true;
			return true;
		}
	}
	
}
