package personagens;

import armas.Desarmado;

public class LutSUMO extends Racional implements Terrestre{
	
	public LutSUMO() {
		super(120, 13);
		super.setArma(new Desarmado());
		super.nome = "LutSUMO";
	}
	
	@Override
	public void desenhar() {
		
	}
	
	public boolean correr() {
		if(super.exausto) {
			System.out.println("Você não consegue correr pois está exausto!");
			return false;
		} else {
			System.out.println("Você corre!");
			super.exausto = true;
			return true;
		}
	}
	
}
