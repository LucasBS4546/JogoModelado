package mainPackage;
import personagens.*;
import armas.*;

public class Jogo {

	public static void main(String[] args) {
		
		introducao();

	}

	public static void introducao() {
		InOut.MsgSemIcone("INTRODUCAO AO JOGO", "Bem vindo ao jogo!\n"
				+ "");
	}
}


