package mainPackage;
import personagens.*;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Jogo {
	
	static ArrayList<Personagem> inimigos = new ArrayList<Personagem>();
	static Personagem jogador, inimigo;
	static boolean isCombat, gameOver;

	public static void main(String[] args) {
		
		gameOver = false;
		introducao();
		jogador = selecionarPersonagem();
		inicializarLista(jogador);
		orientacoes();
		while(!gameOver) {
			isCombat = true;
			if(inimigos.size()<=0) {
				jogadorVenceu();
			} else {				
				sortearInimigo();
			}
			while(true) {
				turnoJogador();
				if(!isCombat) break;
				turnoInimigo();
				if(jogador.HP <= 0) {
					jogadorPerdeu();
				}
				if(!isCombat) break;
			}

		}
		
	}

	public static void introducao() {
		InOut.MsgSemIcone("INTRODUCAO AO JOGO", "Bem vindo ao jogo!\n\n"
				+ "Você poderá escolher entre 3 personagens:\n");
		new Mago().desenhar("INTRODUCAO AO JOGO", "O MAGO\n"
				+ "O mago é um combatente arcano, versátil e de alto dano, mas com pouca vida e resistência.");
		new Soldado().desenhar("INTRODUCAO AO JOGO", "O SOLDADO\n"
				+ "O soldado é armado com um revolver que possui municao. Cuidado, pois ficar sem balas te forcara a usar sua faca!\n"
				+ "Caso voce consiga abater 1 inimigo com o soldado, ele se tornara o GENERAL.");
		new LutSUMO().desenhar("INTRODUCAO AO JOGO", "O LUTADOR DE SUMO\n"
				+ "O lutador de sumo e um lutador de menor dano, mas alta vida. Robusto e lento, ele depende apenas de suas maos para vencer.");
		InOut.MsgSemIcone("INTRODUCAO AO JOGO", "Personagens adicionais:");
		new General().desenhar("INTRODUCAO AO JOGO", "O GENERAL\n"
				+ "A forma sucessora do soldado. O general e armado com um fuzil de altissimo dano e precisao, mas que tambem depende de municao.");
		new DragaoAlado().desenhar("INTRODUCAO AO JOGO", "O DRAGAO\n"
				+ "O personagem nao jogavel do jogo. Vencer ele pode ser dificil!");
		InOut.MsgSemIcone("INTRODUCAO AO JOGO", "Você acha que está pronto para o desafio?");
	}
	
	public static Personagem selecionarPersonagem() {
		int opcao;
		Personagem p;
		while(true) {
			opcao = InOut.leInt("SELECIONE SEU PERSONAGEM\n"
					+ "1: MAGO\n"
					+ "2: SOLDADO\n"
					+ "3: LUTADOR DE SUMO");	
			if(opcao < 1 || opcao > 3) InOut.MsgSemIcone("ERRO", "Digite um valor valido");
			else break;
		}
		switch(opcao) {
		case 1: p = new Mago();
				p.desenhar("MAGO", "Voce escolheu o mago");
				break;
		case 2: p = new Soldado();
				p.desenhar("SOLDADO", "Voce escolheu o soldado");
				break;
		case 3: p = new LutSUMO();
				p.desenhar("LUTADOR DE SUMO", "Voce escolheu o lutador de sumo");
				break;
		default:
				p = new DragaoAlado();
				p.desenhar("ERRO", "Houve um erro inesperado, e o dragao foi selecionado.");
				break;
		}
		return p;
	}
	
	public static void inicializarLista(Personagem j) {
		int i;
		Personagem p;
		for(i=1; i<5; i++) {
			switch(i) {
			case 1: p = new Mago();
					break;
			case 2: p = new Soldado();
					break;
			case 3: p = new LutSUMO();
					break;
			case 4: p = new DragaoAlado();
					break;
			default:
					p = new DragaoAlado();
					break;
			}
			inimigos.add(p);
		}
		for(i=0; i<inimigos.size(); i++) {
			if(inimigos.get(i).nome == j.nome) {
				inimigos.remove(i);
			}
		}
	}
	
	public static void orientacoes() {
		InOut.MsgDeAviso("ATENCAO", "O jogo vai comecar!\n"
				+ "Voce lutara contra 3 inimigos em um combate de turnos. Tente sobreviver e voce vencera!\n\n"
				+ "Em seu turno, voce pode:\n"
				+ "ATACAR, para usar sua arma e atingir seu inimigo\n"
				+ "FALAR, para uma tentativa de resolver o conflito pacificamente\n"
				+ "CORRER, para escapar de uma luta (Voce so pode fazer isso uma vez)");
	}
	
	public static void sortearInimigo() {
				
		int i = new Random().nextInt(inimigos.size());
		inimigo = inimigos.get(i);
		inimigos.remove(i);
		inimigo.desenhar("UM INIMIGO APARECEU!", "Voce se encontrou com o " + inimigo.nome + "!\n"
				+ "O combate inicia!");
		
	}
	
	public static void turnoJogador() {
		boolean FLAG = true;
		while(FLAG) {
			int decisao;
			while(true) {
				decisao = InOut.leInt("SEU TURNO - " + jogador.nome.toUpperCase() + "\n"
						+ "HP: " + jogador.HP + "\n\n"
						+ "Escolha uma acao!\n"
						+ "1: ATACAR\n"
						+ "2: FALAR\n"
						+ "3: CORRER");
				if(decisao < 1 || decisao > 3)
					InOut.MsgDeErro("ERRO DE ENTRADA", "Voce deve escrever um numero valido! Tente novamente.");
				else
					break;
			}
			switch(decisao) {
			case 1: jogadorAtaca();
					FLAG = false;
					break;
			case 2: jogadorFala();
					FLAG = false;
					break;
			case 3:	if(jogador.exausto) InOut.MsgDeErro("FALHA", "Voce nao pode fazer isso pois esta exausto!");
					else {
							jogadorCorre();
							FLAG = false;
						}
					break;
			}
		}
	}
	
	public static void jogadorAtaca() {
		int dano = jogador.arma(inimigo.AC);
		inimigo.HP -= dano;
		if(inimigo.HP <= 0) {
			isCombat = false;
			jogador.abates++;
			InOut.MsgSemIcone("ABATE", "Voce abateu o oponente!");
			if(jogador.nome == "Soldado") {
				jogador = new General();
				jogador.desenhar("PROMOCAO", "\"Eu fui promovido!\"");
				InOut.MsgSemIcone("PROMOCAO", "O soldado foi promovido para General!\n"
						+ "Agora voce tem um fuzil poderoso!");
			}
		}
	}
	
	public static void jogadorFala() {
		String fala = Racional.falar();
		jogador.desenhar("FALAR", "\"" + fala + "\"");
		if(inimigo.nome == "Mago") {
			String[] temp = fala.split("\\s+");
			if(temp.length > 6) {
				inimigo.desenhar("RESPOSTA", "\"Suas palavras me intrigam.\n"
						+ "Vou ir embora por agora...\"");
				InOut.MsgSemIcone("RESPOSTA", "Voce convenceu o oponente a te deixar em paz...");
				isCombat = false;
				jogador.persuasoes++;
			} else {
				inimigo.desenhar("RESPOSTA", "\"Voce e um tolo de cognicao limitada\n"
						+ "Vou te destruir aqui e agora!\"");
			}
		} else if(inimigo.nome == "Lutador de sumo") {
			String[] temp = fala.split("\\s+");
			if(temp.length < 4) {
				inimigo.desenhar("RESPOSTA", "\"Voce e uma pessoa de poucas palavras.\n"
						+ "Eu respeito isso. Vou te poupar.\"");
				InOut.MsgSemIcone("RESPOSTA", "Voce convenceu o oponente a te deixar em paz...");
				isCombat = false;
				jogador.persuasoes++;
			} else {
				inimigo.desenhar("RESPOSTA", "\"Voce fala demais... ISSO ME IRRITA!\n"
						+ "VOU TE DESTRUIR!\"");
			}
		} else if(inimigo.nome == "Dragao Alado") {
			inimigo.desenhar("RESPOSTA", "\"RAAAAAAAAAAAAAAWR\"");
			InOut.MsgSemIcone("RESPOSTA", "Voce realmente pensou que conseguiria conversar com um dragao??");
		} else {
			inimigo.desenhar("RESPOSTA", "\"...\"");
			InOut.MsgSemIcone("RESPOSTA", "O militar parece focado demais para ouvir o que voce disse.");
		}
		
	}
	
	public static void jogadorCorre() {
		isCombat = false;
		jogador.exausto = true;		
		jogador.fugas++;
		InOut.MsgSemIcone("FUGA", "Voce consegue fugir do oponente, mas agora esta exausto! Voce nao podera fugir novamente!");
	}
	
	public static void turnoInimigo() {
		InOut.MsgDeAviso("TURNO DO INIMIGO", inimigo.nome.toUpperCase() + "\n"
				+ "HP: " + inimigo.HP + "\n\n"
				+ "O inimigo vai te atacar!\n");
		int dano = inimigo.arma(jogador.AC);
		jogador.HP -= dano;
	}
	
	public static void jogadorVenceu() {
		jogador.desenhar("VITORIA", "\"Eu venci!\"");
		InOut.MsgSemIcone("VITORIA", "Parabens! Voce sobreviveu os encontros!\n\n"
				+ "ESTATISTICAS:\n"
				+ "-Abates: " + jogador.abates + "\n"
				+ "-Persuasoes: " + jogador.persuasoes + "\n"
				+ "-Fugas: " + jogador.fugas);
		isCombat = false;
		gameOver = true;
	}
	
	public static void jogadorPerdeu() {
		jogador.desenhar("DERROTA", "\"Eu fui derrotado!\"");
		InOut.MsgSemIcone("DERROTA", "Que pena! Voce foi derrotado em um dos encontros!\n\n"
				+ "ESTATISTICAS:\n"
				+ "-Abates: " + jogador.abates + "\n"
				+ "-Persuasoes: " + jogador.persuasoes + "\n"
				+ "-Fugas: " + jogador.fugas);
		isCombat = false;
		gameOver = true;
	}
	

}