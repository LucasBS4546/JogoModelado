package mainPackage;
import personagens.*;
import armas.*;
import java.util.ArrayList;

public class Jogo {
	
	static ArrayList<Personagem> inimigos = new ArrayList<Personagem>();

	public static void main(String[] args) {
		
		Personagem jogador;
		
		introducao();
		jogador = selecionarPersonagem();
		inicializarLista(jogador);
		InOut.MsgDeAviso("ATENCAO", "O jogo vai comecar!\n"
				+ "Voce lutara contra 4 inimigos em um combate de turnos. Tente sobreviver e voce vencera!\n\n"
				+ "Em seu turno, voce pode:\n"
				+ "FALAR, para uma tentativa de resolver o conflito pacificamente\n"
				+ "ATACAR, para usar sua arma e atingir seu inimigo\n"
				+ "CORRER, para escapar de uma luta (Voce so pode fazer isso uma vez)");
		while(jogador.consultarHP() > 0) {
			
			
			
		}
		
	}

	public static void introducao() {
		InOut.MsgSemIcone("INTRODUCAO AO JOGO", "Bem vindo ao jogo!\n\n"
				+ "Você poderá escolher entre 4 personagens:\n");
		InOut.MsgDeInformacao("INTRODUCAO AO JOGO", "O MAGO\n"
				+ "O mago é um combatente arcano, versátil e de alto dano, mas com pouca vida e resistência.");
		InOut.MsgDeInformacao("INTRODUCAO AO JOGO", "O SOLDADO\n"
				+ "O soldado é armado com um revolver que possui municao. Cuidado, pois ficar sem balas te forcara a usar sua faca!\n"
				+ "Caso voce destrua 2 inimigos com o soldado, ele se tornara o GENERAL.", 1);
		InOut.MsgDeInformacao("INTRODUCAO AO JOGO", "O GENERAL\n"
				+ "A forma sucessora do soldado. O general e armado com um fuzil de altissimo dano e precisao, mas que tambem depende de municao.", 2);
		InOut.MsgDeInformacao("INTRODUCAO AO JOGO", "O LUTADOR DE SUMO\n"
				+ "O lutador de sumo e um lutador de menor dano, mas alta vida. Robusto e lento, ele depende apenas de suas maos para vencer.", 3);
		InOut.MsgDeInformacao("INTRODUCAO AO JOGO", "O DRAGAO\n"
				+ "O personagem mais forte do jogo. Apenas o escolha caso queria uma experiencia facil, onde sua alta reisstencia, vida e dano destruira seus inimigos!", 4);
		InOut.MsgSemIcone("INTRODUCAO AO JOGO", "Você acha que está pronto para o desafio?");
	}
	
	public static Personagem selecionarPersonagem() {
		int opcao;
		Personagem p;
		while(true) {
			opcao = InOut.leInt("SELECIONE SEU PERSONAGEM\n"
					+ "1: MAGO\n"
					+ "2: SOLDADO\n"
					+ "3: LUTADOR DE SUMO\n"
					+ "4: DRAGAO");	
			if(opcao < 1 || opcao > 4) InOut.MsgSemIcone("ERRO", "Digite um valor valido");
			else break;
		}
		switch(opcao) {
		case 1: p = new Mago();
				InOut.MsgDeInformacao("MAGO", "Voce escolheu o mago", 0);
				break;
		case 2: p = new Soldado();
				InOut.MsgDeInformacao("SOLDADO", "Voce escolheu o soldado", 1);
				break;
		case 3: p = new LutSUMO();
				InOut.MsgDeInformacao("LUTADOR DE SUMO", "Voce escolheu o lutador de sumo", 3);
				break;
		case 4: p = new DragaoAlado();
				InOut.MsgDeInformacao("DRAGAO", "Voce escolheu o dragao", 4);
				break;
		default:
				p = new DragaoAlado();
				InOut.MsgDeErro("ERRO", "Houve um erro inesperado, e o dragao foi selecionado.");
				break;
		}
		return p;
	}
	
	public static void inicializarLista(Personagem j) {
		int i;
		Personagem p;
		for(i=1; i<6; i++) {
			switch(i) {
			case 1: p = new Mago();
					break;
			case 2: p = new Soldado();
					break;
			case 4: p = new LutSUMO();
					break;
			case 5: p = new DragaoAlado();
					break;
			default:
					p = new DragaoAlado();
					break;
			}
			inimigos.add(p);
		}
		for(i=0; i<inimigos.size(); i++) {
			if(inimigos.get(i).consultarNome() == j.consultarNome()) {
				inimigos.remove(i);
			}
		}
	}
	
	public static void atualizarLista(Personagem p) {
		int i;
		for(i=0; i<inimigos.size(); i++) {
			if(inimigos.get(i).consultarNome() == p.consultarNome()) {
				inimigos.remove(i);
			}
		}
	}

}


