package armas;

import java.util.Random;

import mainPackage.InOut;

public class SoproCongelante implements Arma_IF {
	
	
	@Override
	public int usarArma(int AC) {
		if(girarAcerto()>=AC) 
			return girarDano();
		else {
			InOut.MsgSemIcone("RESULTADO DO ATAQUE", "O ataque errou!");
			return 0;
		}
	}

	@Override
	public int girarAcerto() {
		Random r = new Random();
		int roll = r.nextInt(20) + 1;
		InOut.MsgSemIcone("RESULTADO DO ATAQUE", "Roll de acerto (1d20): " + roll);
		return roll;
	}

	@Override
	public int girarDano() {
		Random r = new Random();
		int roll = r.nextInt(10) + 1;
		InOut.MsgSemIcone("RESULTADO DO ATAQUE", "Roll de dano (1d10): " + roll);
		return roll;
	}
}