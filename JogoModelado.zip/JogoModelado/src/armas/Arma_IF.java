package armas;

public interface Arma_IF {

	
	public int usarArma(int AC);
	
	public int girarAcerto();
	
	public int girarDano();
	
}
