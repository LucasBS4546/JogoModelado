package armas;

import java.util.Random;

import mainPackage.InOut;

public class Magia implements Arma_IF {
	
	@Override
	public int usarArma(int AC) {
		if(girarAcerto()>=AC) 
			return girarDano();
		else {
			InOut.MsgSemIcone("RESULTADO DO ATAQUE", "O ataque errou!");
			return 0;
		}
	}

	@Override
	public int girarAcerto() {
		Random r = new Random();
		int roll = r.nextInt(20) + 11;
		InOut.MsgSemIcone("RESULTADO DO ATAQUE", "Roll de acerto com a magia (1d20+10): " + roll);
		return roll;
	}

	@Override
	public int girarDano() {
		Random r = new Random();
		int roll = r.nextInt(10) + 6;
		InOut.MsgSemIcone("RESULTADO DO ATAQUE", "Roll de dano da magia (1d10+5): " + roll);
		return roll;
	}
	
	
}