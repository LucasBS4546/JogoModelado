package armas;

import java.util.Random;

import mainPackage.InOut;

public class Fuzil implements Arma_IF {
	
	int municao;
	
	public Fuzil() {
		municao = 20;
	}
	
	@Override
	public int usarArma(int AC) {
		if(municao <= 0) {
			InOut.MsgDeAviso("SEM MUNICAO", "O seu fuzil ficou sem municao!\n"
					+ "Agora voce esta usando sua faca!");
			return -1;
		} else {
			municao--;
			if(girarAcerto()>=AC) 
				return girarDano();
			else {
				System.out.println("O ataque errou!");
				return 0;
			}
			
		}
	}

	@Override
	public int girarAcerto() {
		Random r = new Random();
		int roll = r.nextInt(20) + 11;
		System.out.println("Roll de acerto (1d20+10): " + roll);
		return roll;
	}

	@Override
	public int girarDano() {
		Random r = new Random();
		int roll = r.nextInt(12) + 1;
		System.out.println("Roll de dano (1d12): " + roll);
		return roll;
	}
}