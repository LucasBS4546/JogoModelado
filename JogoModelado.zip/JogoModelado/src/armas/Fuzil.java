package armas;

import java.util.Random;

import mainPackage.InOut;

public class Fuzil implements Arma_IF {
	
	int municao;
	
	public Fuzil() {
		municao = 20;
	}
	
	@Override
	public int usarArma(int AC) {
		if(municao <= 0) {
			InOut.MsgDeAviso("SEM MUNICAO", "O seu fuzil ficou sem municao!\n"
					+ "Agora voce esta usando sua faca!");
			return -1;
		} else {
			municao--;
			if(girarAcerto()>=AC) 
				return girarDano();
			else {
				InOut.MsgSemIcone("RESULTADO DO ATAQUE", "O ataque errou!");
				return 0;
			}
			
		}
	}

	@Override
	public int girarAcerto() {
		Random r = new Random();
		int roll = r.nextInt(20) + 16;
		InOut.MsgSemIcone("RESULTADO DO ATAQUE", "Roll de acerto com o fuzil (1d20+15): " + roll);
		return roll;
	}

	@Override
	public int girarDano() {
		Random r = new Random();
		int roll = r.nextInt(12) + 11;
		InOut.MsgSemIcone("RESULTADO DO ATAQUE", "Roll de dano do fuzil (1d12+10): " + roll);
		return roll;
	}
}