package armas;

import java.util.Random;

public class Revolver implements Arma_IF {
	
	
	@Override
	public int usarArma(int AC) {
		if(girarAcerto()>=AC) 
			return girarDano();
		else {
			System.out.println("O ataque errou!");
			return 0;
		}
	}

	@Override
	public int girarAcerto() {
		Random r = new Random();
		int roll = r.nextInt(20) + 8;
		System.out.println("Roll de acerto (1d20+7): " + roll);
		return roll;
	}

	@Override
	public int girarDano() {
		Random r = new Random();
		int roll = r.nextInt(8) + 1;
		System.out.println("Roll de dano (1d8): " + roll);
		return roll;
	}
	
}