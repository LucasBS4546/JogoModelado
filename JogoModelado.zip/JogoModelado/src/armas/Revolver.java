package armas;

import java.util.Random;

import mainPackage.InOut;

public class Revolver implements Arma_IF {
	
	int municao;
	
	public Revolver(){
		municao = 6;
	}
	
	@Override
	public int usarArma(int AC) {
		if(municao <= 0) {
			InOut.MsgDeAviso("SEM MUNICAO", "O seu revolver ficou sem municao!\n"
					+ "Agora voce esta usando sua faca!");
			return -1;
		} else {
			municao--;
			if(girarAcerto()>=AC) 
				return girarDano();
			else {
				InOut.MsgSemIcone("RESULTADO DO ATAQUE", "O ataque errou!");
				return 0;
			}
		}
		
	}

	@Override
	public int girarAcerto() {
		Random r = new Random();
		int roll = r.nextInt(20) + 7;
		InOut.MsgSemIcone("RESULTADO DO ATAQUE", "Roll de acerto com o revolver (1d20+6): " + roll);
		return roll;
	}

	@Override
	public int girarDano() {
		Random r = new Random();
		int roll = r.nextInt(8) + 6;
		InOut.MsgSemIcone("RESULTADO DO ATAQUE", "Roll de dano do revolver (1d8+5): " + roll);
		return roll;
	}
	
}