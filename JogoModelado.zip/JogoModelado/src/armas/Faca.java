package armas;

import java.util.Random;

import mainPackage.InOut;

public class Faca implements Arma_IF {
	
	
	@Override
	public int usarArma(int AC) {
		if(girarAcerto()>=AC) 
			return girarDano();
		else {
			InOut.MsgSemIcone("RESULTADO DO ATAQUE", "O ataque errou!");
			return 0;
		}
	}

	@Override
	public int girarAcerto() {
		Random r = new Random();
		int roll = r.nextInt(20) + 5;
		InOut.MsgSemIcone("RESULTADO DO ATAQUE", "Roll de acerto com a faca (1d20+4): " + roll);
		return roll;
	}

	@Override
	public int girarDano() {
		Random r = new Random();
		int roll = r.nextInt(4) + 2;
		InOut.MsgSemIcone("RESULTADO DO ATAQUE", "Roll de dano da faca (1d4+1): " + roll);
		return roll;
	}
}